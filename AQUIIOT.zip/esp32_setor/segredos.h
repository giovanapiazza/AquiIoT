#pragma once

// NAO envie este arquivo ao Git (ja esta no Setor/.gitignore).
const char* WIFI_STA_SSID = "a22";
const char* WIFI_STA_SENHA = "fablab2211";
// API publica da Raspberry Pi (Tailscale Funnel), sem barra no final.
const char* URL_BACKEND = "https://raspberrypi.tail656d5e.ts.net";
